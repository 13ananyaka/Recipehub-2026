const express = require('express');
const dotenv = require('dotenv');
const connectDB = require('./config/db');

dotenv.config();
connectDB();

const app = express();
app.use(express.json());

app.use('/api/users', require('./routes/userRoutes'));

app.listen(process.env.PORT, () =>
  console.log(`User Service running on ${process.env.PORT}`)
);